import _ from "lodash";

export class GenericDatasource {

  constructor(instanceSettings, $q, backendSrv, templateSrv) {
    this.type = instanceSettings.type;
    this.url = instanceSettings.url;
    this.name = instanceSettings.name;
    this.q = $q;
    this.backendSrv = backendSrv;
    this.templateSrv = templateSrv;

    this.severityLevels = {}
    if (instanceSettings.jsonData.severity_critical != undefined) {
      this.severityLevels[instanceSettings.jsonData.severity_critical.toLowerCase()] = 4;
    }
    if (instanceSettings.jsonData.severity_high != undefined) {
      this.severityLevels[instanceSettings.jsonData.severity_high.toLowerCase()] = 3;
    }
    if (instanceSettings.jsonData.severity_warning != undefined) {
      this.severityLevels[instanceSettings.jsonData.severity_warning.toLowerCase()] = 2;
    }
    if (instanceSettings.jsonData.severity_info != undefined) {
      this.severityLevels[instanceSettings.jsonData.severity_info.toLowerCase()] = 1;
    }
  }

  query(options) {
    let query = this.buildQueryParameters(options);
    query.targets = query.targets.filter(t => !t.hide);

    if (query.targets.length <= 0) {
      return this.q.when({data: []});
    }
    // Format data for table panel
    if(query.targets[0].type === "table"){
      var labelSelector = this.parseLabelSelector(query.targets[0].labelSelector);
      let filter = encodeURIComponent(this.templateSrv.replace(query.targets[0].expr, options.scopedVars, this.interpolateQueryExpr) || "");
      return this.backendSrv.datasourceRequest({
        url: this.url + '/api/alma/alarms',
        data: query,
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
      }).then(response => {
        let results = {
          "data": [{
            "rows": [],
            "columns": [],
            "type": "table"
          }]
        };

	console.log(response);

        //if(response.data && response.data.data && response.data.data.length) {
        if(response && response.data && response.data.length) {
          let columnsDict = this.getColumnsDict(response.data[0], labelSelector);
	  console.log(columnsDict);

          results.data[0].columns = this.getColumns(columnsDict);

	  console.log(results.data[0].columns);

          for (let i = 0; i < response.data.length; i++) {
            let row = new Array(results.data[0].columns.length).fill("");
            let item = response.data[i];
            row[0] = [Date.parse(item['createdAt'])];

            for (let label of Object.keys(item)) {
              if(label in columnsDict) {
                  row[columnsDict[label]] = item[label];
              }
            }
	   
	    console.log(row);

            results.data[0].rows.push(row);
          }
        }

	console.log(results);

        return results;
      });
    } else {
      let filter = encodeURIComponent(this.templateSrv.replace(query.targets[0].expr, options.scopedVars, this.interpolateQueryExpr) || "");
      return this.backendSrv.datasourceRequest({
        url: this.url + '/api/alam/alarms',
        data: query,
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
      }).then(response => {
        return {
          "data": [{ "datapoints": [ [response.data.length, Date.now()] ]}]
        }
      });
    }
  }

  interpolateQueryExpr(value, variable, defaultFormatFn) {
    if (typeof value === 'string') {
      return dsSpecialRegexEscape(value);
    }

    let escapedValues = _.map(value, dsSpecialRegexEscape);
    return escapedValues.join('|');
  }

  getColumns(columnsDict) {
    let columns =  [{ text: "Time", type: "time" }];
    for(let column of Object.keys(columnsDict)) {
      columns.push({ text: column, type: "string" })
    }
    return columns;
  }

  // Parses the label list into a map
  parseLabelSelector(input) {
    var map;
    if (typeof(input) === "undefined" || input.trim().length === 0) {
      map = ["*"];
    } else {
      map = input.trim().split(/\s*,\s*/);
    }
    return map;
  }

  // Creates a column index dictionary in to assist in data row construction
  getColumnsDict(data, labelSelector) {
    let index = 1; // 0 is the data column
    let columnsDict = {};
    let severityDefined = false;

    console.log(data);
    console.log(labelSelector);

    //for (let i = 0; i < data.length; i++) {
      for (let labelIndex = 0; labelIndex < labelSelector.length; labelIndex++) {
        var selectedLabel = labelSelector[labelIndex];
        if (selectedLabel === "*") {
          // '*' maps to all labels/annotations not already added via the label selector list

	  console.log(Object.keys(data));

          for (let label of Object.keys(data)) {
              columnsDict[label] = index++;
          }
        } else if (!(selectedLabel in columnsDict)) {
          if (selectedLabel === 'severity') {
            severityDefined = true
          }
          columnsDict[selectedLabel] = index++;
        }
      }
    //}
    if (!severityDefined) {
      columnsDict['severity'] = index++;
    }
    return columnsDict;
  }

  testDatasource() {
    return this.backendSrv.datasourceRequest({
      url: this.url + '/api/alma/alarms',
      method: 'GET'
    }).then(response => {
      if (response.status === 200) {
        return { status: "success", message: "Data source is working", title: "Success" };
      }
    });
  }

  buildQueryParameters(options) {
    //remove placeholder targets
    options.targets = _.filter(options.targets, target => {
      return target.target !== 'select metric';
    });

    options.targetss = _.map(options.targets, target => {
      return {
        target: this.templateSrv.replace(target.target),
        expr: target.expr,
        refId: target.refId,
        hide: target.hide,
        type: target.type || 'single',
        legendFormat: target.legendFormat || ""
      };
    });
    return options;
  }

  formatInstanceText(labels, legendFormat){
    if(legendFormat === ""){
      return JSON.stringify(labels);
    }
    let aliasRegex = /\{\{\s*(.+?)\s*\}\}/g;
    return legendFormat.replace(aliasRegex, function(match, g1) {
      if (labels[g1]) {
        return labels[g1];
      }
      return "";
    });
  }


}
export function dsRegularEscape(value) {
  if (typeof value === 'string') {
    return value.replace(/'/g, "\\\\'");
  }
  return value;
}

export function dsSpecialRegexEscape(value) {
  if (typeof value === 'string') {
    return dsRegularEscape(value.replace(/\\/g, '\\\\\\\\').replace(/[$^*{}\[\]+?.()]/g, '\\\\$&'));
  }
  return value;
}
